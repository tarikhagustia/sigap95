<section class="home-section bg-dark-alfa-90 parallax-2" data-background="<?php echo base_url() ?>/assets/images/full-width-images/maintenance.jpg">
    <div class="js-height-full">

        <!-- Hero Content -->
        <div class="home-content container">
            <div class="home-text">
                <div class="hs-cont">

                    <!-- Headings -->
                    <div class="hs-wrap">

                        <div class="hs-line-12 font-alt mb-10">
                            MAAF
                        </div>

                        <div class="hs-line-6 no-transp font-alt mb-40">
                            Kami sedang melakukan Perbaikan
                        </div>

                        <p>
                            Nantikan kejutan istimewa dari kami, Berbagai produk - produk Percetakan yang berguna bagi Bisnis Anda
                        </p>

                    </div>
                    <!-- End Headings -->

                </div>
            </div>
        </div>
        <!-- End Hero Content -->

    </div>
</section>
