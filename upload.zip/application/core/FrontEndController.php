<?php
class FrontEndController extends MX_Controller
{
  public function __construct()
  {
    parent::__construct();
  }
}
