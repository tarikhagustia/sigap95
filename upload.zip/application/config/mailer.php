<?php
$config['m_host'] = 'mail.terasberita.co';
$config['m_username'] = 'mailer@terasberita.co';
$config['m_password'] = 'mailer1234';
// $config['m_smtp_secure'] = 'tls';
$config['m_port'] = 25;
?>
