<?php
$config['header_css'] = [];
$config['header_js']  = [];
$config['meta_article']  = false;
$config['meta_article_url']  = null;
?>
