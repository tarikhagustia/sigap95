<?php
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'tls://mail.terasberita.co'; //change this
    $config['smtp_port'] = '25';
    $config['smtp_user'] = 'no-reply@terasberita.co'; //change this
    $config['smtp_pass'] = 'mugen1996'; //change this
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes to comply with RFC 822 standard
?>